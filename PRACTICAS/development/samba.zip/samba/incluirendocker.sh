services:
  samba_dev:
    build: ./development/samba
    container_name: samba_dev
    networks:
      development_net:
        ipv4_address: 172.40.0.12
    volumes:
      - ./development/samba/data:/data
    cap_add:
      - NET_ADMIN

